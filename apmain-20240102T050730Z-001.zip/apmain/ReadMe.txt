Assumptions

1.Since it wasn't explicitly mentioned whether one visitor can only have one kind of membership, according to my code one 
user can have both basic and premium membership, also it is assumed
that once a visitor has bought a certain membership he/she would not visit the option of buying membership again.


2.While buying an attraction, the viewer is not able to view the price of the attraction. The costs of all attractions
are set to 10 by default. Editing the price is possible.


3.For a particular attraction, number of ticketed visitors does not include the people who visited using premium membership.
4.If number of tickets bought matches the criteria of a certain special deal, then on the next ticket bought we can use
the special deal. The special deal is using the assumption that higher number of tickets bought is associated with a higher
discount percentage.

5.The number of visitors is the sum of the number of registrations and logins


HOME_FOLDER = src
0. Download the src code folder from Classroom and unzip.
1. mvn clean 
2. mvn compile
3. mvn package
4.For entering into the main program: java -jar target\apmain-1.0-SNAPSHOT.jar
