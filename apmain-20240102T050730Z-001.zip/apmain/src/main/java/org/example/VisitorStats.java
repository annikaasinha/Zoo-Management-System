package org.example;

public class VisitorStats {
    private int noOfVisitors;
    private double revenue;
    //how to find most popular attraction
    public VisitorStats(int noOfVisitors, double revenue){
        this.noOfVisitors=noOfVisitors;
        this.revenue=revenue;
    }

    public int getNoOfVisitors() {
        return noOfVisitors;
    }

    public void setNoOfVisitors(int noOfVisitors) {
        this.noOfVisitors = noOfVisitors;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = revenue;
    }

    @Override
    public String toString() {
        return "The total number of Visitors are "+this.noOfVisitors+"\nThe total revenue is "+this.revenue;
    }
}
