package org.example;

import org.w3c.dom.Attr;

import java.sql.SQLOutput;
import java.util.*;

public class VisitorManager implements Visitor {
    private ArrayList<VisitorClass> visitorDetails=new ArrayList<>();
    private boolean loginSuccessful=false;
    private boolean registrationSuccessful=false;
    private String particularMemberEmail;
    private String particularMemberPassword;

    public String getParticularMemberEmail() {
        return particularMemberEmail;
    }

    public void setParticularMemberEmail(String particularMemberEmail) {
        this.particularMemberEmail = particularMemberEmail;
    }

    public String getParticularMemberPassword() {
        return particularMemberPassword;
    }

    public void setParticularMemberPassword(String particularMemberPassword) {
        this.particularMemberPassword = particularMemberPassword;
    }

    @Override
    public void register(ZooManager zoo) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Visitor Name:");

        String visitorName=sc.nextLine();
        System.out.println("Enter Visitor Age:");
        int visitorAge=sc.nextInt();
        System.out.println("Enter Visitor Phone Number:");
        //sc.next since phone number has no spaces
        String visitorPhoneNumber=sc.next();
        System.out.println("Enter Visitor Balance:");
        double visitorBalance=sc.nextDouble();
        System.out.println("Enter Visitor Email:");
        String visitorEmail=sc.next();
        System.out.println("Enter Visitor Password:");
        String visitorPassword=sc.next();
        VisitorClass visitor=new VisitorClass(visitorName, visitorAge, visitorPhoneNumber, visitorBalance, visitorEmail, visitorPassword);
        visitorDetails.add(visitor);
        System.out.println("Registration is successful.");
        this.setParticularMemberEmail(visitorEmail);
        this.setParticularMemberPassword(visitorPassword);
        this.setRegistrationSuccessful(true);

        int a1=zoo.getVisitorStats().getNoOfVisitors();
        zoo.getVisitorStats().setNoOfVisitors(a1+1);
    }

    @Override
    public boolean login(ZooManager zoo) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Visitor Email: ");
        String visitorEmail = sc.next();
        System.out.println("Enter Visitor Password: ");
        String visitorPassword = sc.next();

        for (VisitorClass v : visitorDetails) {
            System.out.println("Debug: Stored Email: " + v.getVisitorEmail() + ", Stored Password: " + v.getVisitorPassword());
            if (v.getVisitorEmail().equals(visitorEmail) && v.getVisitorPassword().equals(visitorPassword)) {
                System.out.println("Logged in successfully ");
                zoo.getVisitorStats().setNoOfVisitors(zoo.getVisitorStats().getNoOfVisitors() + 1);
                this.setLoginSuccessful(true);
                return true;// Exit the loop once a successful login is found.
            }
        }

        // If the loop completes without a successful login, print an error message.
        System.out.println("Login failed. Invalid email or password.");
        return false;
    }








    public ArrayList<VisitorClass> getVisitorDetails() {
        return visitorDetails;
    }

    public boolean isLoginSuccessful() {
        return loginSuccessful;
    }

    public boolean isRegistrationSuccessful() {
        return registrationSuccessful;
    }

    public void setLoginSuccessful(boolean loginSuccessful) {
        this.loginSuccessful = loginSuccessful;
    }

    public void setVisitorDetails(ArrayList<VisitorClass> visitorDetails) {
        this.visitorDetails = visitorDetails;
    }

    public void setRegistrationSuccessful(boolean registrationSuccessful) {
        this.registrationSuccessful = registrationSuccessful;
    }

    @Override
    public void exploreZoo(ZooManager zoo) {
        if(registrationSuccessful||loginSuccessful){
            while(true){
                Scanner sc=new Scanner(System.in);
                System.out.println("Explore the Zoo:\n" +
                        "1. View Attractions\n" +
                        "2. View Animals\n" +
                        "3. Exit\n");
                int exploreZooOption=sc.nextInt();
                if(exploreZooOption==1){
                    int i=1;


                    for(Attraction attraction:zoo.getAttractionArrayList()){
                        System.out.print(i);
                        System.out.print(" ");
                        System.out.println(attraction);
                        i=i+1;

                    }
                    System.out.println("Enter your choice: ");



                } else if (exploreZooOption==2) {
                    for(Animal a: zoo.getAnimalArrayList()){
                        System.out.println(a);
                    }
                } else if (exploreZooOption==3) {
                    break;

                }
            }
        }

    }

    @Override
    public void buyMembership(ZooManager zoo) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Buy Membership:\n" +
                "1. Basic Membership (₹20)\n" +
                "2. Premium Membership (₹50)\n");

        int buyMembershipOption = sc.nextInt();
        System.out.println("Following are the discount codes:" +
                "\n1.Senior citizen Discount " + zoo.getSeniorDiscount().toString() + "\n2. Minor citizen discount" + zoo.getMinorDiscount().toString() + "\n3.None");
        System.out.println("Apply discount code: ");
        int discountOption = sc.nextInt();
        double costToPay = 0;
        if (buyMembershipOption == 1) {
            costToPay = 20;
        } else if (buyMembershipOption == 2) {
            costToPay = 50;

        }
        if (discountOption == 2) {
            for (VisitorClass visitorClass : visitorDetails) {
                if (visitorClass.getVisitorEmail().equals(particularMemberEmail)) {
                    int visitorAge = visitorClass.getVisitorAge();
                    boolean visitorMembershipB = visitorClass.isHasBasicMembership();
                    boolean visitorMembershipP = visitorClass.isHasPremiumMembership();
                    if (visitorAge < 18) {

                        double subtractAmount = zoo.getMinorDiscount().getMinorDiscount();
                        if(costToPay==50){
                            visitorClass.setHasPremiumMembership(true);
                        }
                        else {
                            visitorClass.setHasBasicMembership(true);
                        }
                        costToPay = costToPay - (subtractAmount * costToPay);
                        double toSet = visitorClass.getBalance() - costToPay;
                        zoo.getVisitorStats().setRevenue(zoo.getVisitorStats().getRevenue() + costToPay);
                        visitorClass.setBalance(toSet);
                        System.out.print("Membership bought successfully, balance left is ");

                        System.out.println(visitorClass.getBalance());

                    } else {
                        System.out.println("I'm sorry, but you don't fulfill the criteria");
                    }
                }
            }
        } else if (discountOption == 1) {
            for (VisitorClass visitorClass : visitorDetails) {
                if (visitorClass.getVisitorEmail() == particularMemberEmail) {
                    if (visitorClass.getVisitorAge() > 60) {
                        if(costToPay==50){
                            visitorClass.setHasPremiumMembership(true);
                        }
                        else {
                            visitorClass.setHasBasicMembership(true);
                        }
                        double subtractAmount = zoo.getSeniorDiscount().viewDiscount();
                        costToPay = costToPay - subtractAmount * costToPay;
                        double toSet = visitorClass.getBalance() - costToPay;
                        zoo.getVisitorStats().setRevenue(zoo.getVisitorStats().getRevenue() + costToPay);
                        visitorClass.setBalance(toSet);
                        System.out.print("Membership bought successfully, balance left is ");
                        System.out.println(visitorClass.getBalance());

                    } else {
                        System.out.println("I'm sorry but you don't fulfil the criteria");
                    }
                }
            }

        } else if (discountOption == 3) {
            for (VisitorClass visitorClass : visitorDetails) {
                if (visitorClass.getVisitorEmail() == particularMemberEmail) {


                    zoo.getVisitorStats().setRevenue(zoo.getVisitorStats().getRevenue() + costToPay);
                    visitorClass.setBalance(visitorClass.getBalance() - costToPay);
                    System.out.print("Membership bought successfully, balance left is ");
                    System.out.println(visitorClass.getBalance());


                    if (buyMembershipOption == 1) {
                        for (VisitorClass v : this.getVisitorDetails()) {
                            zoo.getVisitorStats().setRevenue(zoo.getVisitorStats().getRevenue() + 20);
                            v.setBalance(v.getBalance() - 20);
                            v.setHasBasicMembership(true);
                        }
                    }


                }
            }
        }
    }

    @Override
    public void buyTickets(ZooManager zoo) {
        Scanner sc = new Scanner(System.in);
        for (VisitorClass v : visitorDetails) {
            if (v.getVisitorEmail() == particularMemberEmail) {
                //assuming that therefore password has to be relevant
                if (v.isHasBasicMembership()) {
                    System.out.println("Since you have the basic membership you can purchase the ticket");
                    int i = 1;
                    // Create a map to associate the index with attractions
                    Map<Integer, Attraction> attractionMap = new HashMap<>();
                    for (Attraction attraction : zoo.getAttractionArrayList()) {
                        System.out.print(i);
                        System.out.print(" ");
                        System.out.println(attraction);
                        // Add the attraction to the map with the current index
                        attractionMap.put(i, attraction);
                        i++;
                    }

                    System.out.println("Enter your choice:");
                    int attractionToVisit = sc.nextInt();
                    Attraction selectedAttraction = attractionMap.get(attractionToVisit);

                    for (Attraction attraction : zoo.getAttractionArrayList()) {
                        if (attraction.getName().equals(selectedAttraction.getName())) {
                            int maxNoOfAttractionCondition = 0;
                            double bufferSpecialDeal = 0;


                            //look at the maximum among all the limits so i need a crete a hashmap here as well
                            for (SpecialDeals specialDeals : zoo.getSpecialDealsArrayList()) {
                                int lowerLimit = specialDeals.getNoOfAttractionsBought();
                                if (v.getBasicMembership().getNoOfTicketsBought() > lowerLimit) {
                                    if (specialDeals.getCorrespondingDeals() > bufferSpecialDeal) {
                                        bufferSpecialDeal = specialDeals.getCorrespondingDeals();
                                    }
                                }
                            }
                            double costToPay = attraction.getAttractionPrice() - bufferSpecialDeal * attraction.getAttractionPrice();
                            attraction.setNumberOfTicketedVisitors(attraction.getNumberOfTicketedVisitors() + 1);
                            v.getBasicMembership().getTicketsBought().add(attraction);
                            v.setBalance(v.getBalance() - costToPay);
                            zoo.getVisitorStats().setRevenue(zoo.getVisitorStats().getRevenue() + costToPay);
                            System.out.println("Ticket bought successfully!");
                        }
                    }
                }
            } else {
                System.out.println("Only basic members can buy these tickets to specific attractions");
            }
        }
    }



    @Override
    public void viewDiscounts(ZooManager zoo) {
        System.out.println("View Discounts:\n");
        double minorDiscount=zoo.getMinorDiscount().getMinorDiscount();
        minorDiscount=minorDiscount*100;
        System.out.print("Minor discounts are: ");
        System.out.print(minorDiscount);
        System.out.println("%");
        System.out.print("Senior discounts are: ");
        double seniorDiscount=zoo.getSeniorDiscount().viewDiscount();
        seniorDiscount=seniorDiscount*100;
        System.out.println(seniorDiscount);
        System.out.println("%");
    }

    @Override
    public void applyDiscounts() {

    }

    @Override
    public void visitAttraction(ZooManager zoo) {
        Scanner sc=new Scanner(System.in);
        int i=1;
        Map<Integer, Attraction> attractionMap = new HashMap<>();
        for(Attraction attraction: zoo.getAttractionArrayList()){
            attractionMap.put(i, attraction);
            System.out.print(i);
            System.out.print(" ");
            System.out.println(attraction);
            i++;
        }
        System.out.println("Enter your choice:");
        int attractionToVisit=sc.nextInt();
        Attraction selectedAttraction = attractionMap.get(attractionToVisit);
        boolean isAllowedToVisit=false;

            for (VisitorClass v : this.getVisitorDetails()) {
                if (v.getVisitorEmail() == this.particularMemberEmail) {
                    if (v.isHasPremiumMembership()) {
for(Attraction attraction: zoo.getAttractionArrayList()) {
    if (attraction.getName() == selectedAttraction.getName()) {
        if (attraction.isOpen() == true) {
            attraction.visitAttraction();
            isAllowedToVisit = true;
        } else {
            System.out.println("Sorry the attraction is closed");
        }
    }
}

                    } else if (v.isHasBasicMembership()) {
                        for (Attraction attraction : v.getBasicMembership().getTicketsBought()) {

                            if (attraction.getName() == selectedAttraction.getName()) {
                                attraction.visitAttraction();
                                System.out.println("1 ticket for this attraction is exhausted");
                                isAllowedToVisit = true;
                                v.getBasicMembership().getTicketsBought().remove(selectedAttraction);
                            }
                        }

                    }
                    else{
                        System.out.println("You have not purchased any membership");
                    }
                    if (isAllowedToVisit == false) {
                        if (v.isHasBasicMembership()) {
                            System.out.println("Ticket not available. Basic Members need to buy separate tickets for the attractions.");
                        } else if (v.isHasPremiumMembership()) {
                            System.out.println("Some Error");

                        }
                    }
                }
            }




    }

    @Override
    public void provideFeedback(ZooManager zoo) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Please provide the feedback:");
        String feedback=sc.nextLine();
        System.out.println(feedback);
        Feedback feedback1=new Feedback(feedback);
        zoo.getFeedbackArrayList().add(feedback1);


    }

    @Override
    public void viewSpecialDeals(ZooManager zoo) {
        for(SpecialDeals specialDeals: zoo.getSpecialDealsArrayList()){
            System.out.println(specialDeals);
        }

    }

    @Override
    public void visitAnimals(ZooManager zoo) {
        Scanner sc=new Scanner(System.in);
        HashMap<Integer, Animal> animalMap = new HashMap<>();
int i=1;
        for (Animal animal : zoo.getAnimalArrayList()) {
            System.out.print(i + ".");
            System.out.println(animal);

            // Put the animal in the HashMap with its index
            animalMap.put(i, animal);
            i++;
        }

        System.out.println("Enter your choice: ");
        int choice = sc.nextInt();

        // Retrieve the selected animal from the HashMap
        Animal selectedAnimal = animalMap.get(choice);
        System.out.println("Would you like to\n1.Feed the animal\n2. Read about the animal");
        int animalOption=sc.nextInt();
        if(animalOption==1){
            selectedAnimal.feed();
        } else if (animalOption==2) {
            selectedAnimal.getDescription();
        }

    }

    }

