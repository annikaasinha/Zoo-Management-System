package org.example;

public interface Feedbackable {
    public void addFeedback(String feedback);
    public void viewFeedback();
}
