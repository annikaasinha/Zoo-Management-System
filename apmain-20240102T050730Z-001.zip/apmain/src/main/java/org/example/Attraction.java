package org.example;

import java.util.ArrayList;

public class Attraction extends ZooEntity{
private int attractionID;
private ArrayList<Animal> animalArrayList;
private boolean isOpen;
    private Mammal dummyMammal=new Mammal("dummy", "dummy", "dummy");
    private double AttractionPrice;
private int numberOfTicketedVisitors=0;
    public Attraction(String name, String description, int id, double attractionPrice) {
    super(name, description);
    this.attractionID=id;
    animalArrayList=new ArrayList<>();
    getAnimalArrayList().add(dummyMammal);
    isOpen=true;
    this.AttractionPrice=attractionPrice;

    }

    public int getNumberOfTicketedVisitors() {
        return numberOfTicketedVisitors;
    }

    public void setNumberOfTicketedVisitors(int numberOfTicketedVisitors) {
        this.numberOfTicketedVisitors = numberOfTicketedVisitors;
    }

    public void setAnimalArrayList(ArrayList<Animal> animalArrayList) {
        this.animalArrayList = animalArrayList;
    }

    public ArrayList<Animal> getAnimalArrayList() {
        return animalArrayList;
    }

    public int getAttractionID() {
        return attractionID;
    }

    public void setAttractionID(int attractionID) {
        this.attractionID = attractionID;
    }

    @Override
    public String toString() {
        return this.getAttractionID()+" "+this.getName();

    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }
    public void visitAttraction(){
        System.out.print("Welcome to Attraction ");
        System.out.println(this.getName());
    }
    public double getAttractionPrice(){
        return this.AttractionPrice;
    }

    public void setAttractionPrice(double attractionPrice) {
        AttractionPrice = attractionPrice;
    }
}
