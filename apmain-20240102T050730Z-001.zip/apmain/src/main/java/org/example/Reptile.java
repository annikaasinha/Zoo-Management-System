package org.example;

public class Reptile extends Animal{
//at least 2 instances of Reptile
    public Reptile(String animalName, String description, String feedNoise) {
        super(animalName, description, feedNoise);
    }
}
