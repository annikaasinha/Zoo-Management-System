package org.example;

public abstract class Animal extends ZooEntity{
    private String feedNoise;

    //this is the class that helps in adding new animals
    public Animal( String animalName, String description, String feedNoise){
      super(animalName, description);
      this.feedNoise=feedNoise;
    }
    public void feed(){
        System.out.println(feedNoise);
    }

    public String getFeedNoise() {
        return feedNoise;
    }

    public void setFeedNoise(String feedNoise) {
        this.feedNoise = feedNoise;
    }
}
