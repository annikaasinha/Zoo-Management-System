package org.example;

import java.util.ArrayList;

public class VisitorClass {
    private String visitorName;
    private int visitorAge;
    private String phoneNumber;
    private double balance;
    private String visitorEmail;
    private String visitorPassword;
    private boolean hasBasicMembership;
    private boolean hasPremiumMembership;
    private BasicMembership basicMembership=new BasicMembership();
    public VisitorClass(String visitorName, int visitorAge, String phoneNumber, double balance, String visitorEmail, String visitorPassword){
        this.visitorName=visitorName;
        this.visitorAge=visitorAge;
        this.balance=balance;
        this.visitorEmail=visitorEmail;
        this.visitorPassword=visitorPassword;
        this.hasBasicMembership=false;
        this.hasPremiumMembership=false;
    }

    public BasicMembership getBasicMembership() {
        return basicMembership;
    }

    public void setBasicMembership(BasicMembership basicMembership) {
        this.basicMembership = basicMembership;
    }

    public boolean isHasBasicMembership() {
        return hasBasicMembership;
    }

    public boolean isHasPremiumMembership() {
        return hasPremiumMembership;
    }

    public void setHasBasicMembership(boolean hasBasicMembership) {
        this.hasBasicMembership = hasBasicMembership;
    }

    public void setHasPremiumMembership(boolean hasPremiumMembership) {
        this.hasPremiumMembership = hasPremiumMembership;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public double getBalance() {
        return balance;
    }

    public int getVisitorAge() {
        return visitorAge;
    }

    public String getVisitorEmail() {
        return visitorEmail;
    }

    public String getVisitorName() {
        return visitorName;
    }

    public String getVisitorPassword() {
        return visitorPassword;
    }

    public void setVisitorAge(int visitorAge) {
        this.visitorAge = visitorAge;
    }

    public void setVisitorEmail(String visitorEmail) {
        this.visitorEmail = visitorEmail;
    }

    public void setVisitorName(String visitorName) {
        this.visitorName = visitorName;
    }

    public void setVisitorPassword(String visitorPassword) {
        this.visitorPassword = visitorPassword;
    }
}
