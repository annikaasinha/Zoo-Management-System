package org.example;

public class MinorDiscount implements Discountable{
    private double minorDiscount=0.1;
    public MinorDiscount(double minorDiscount){
        this.minorDiscount=minorDiscount;
    }

    @Override
    public String toString() {
        return " "+this.minorDiscount;
    }


    @Override
    public double viewDiscount() {
        return minorDiscount;
    }

    @Override
    public void setDiscount(double Discount) {
        this.minorDiscount=Discount;
    }

    public double getMinorDiscount() {
        return minorDiscount;
    }
}
