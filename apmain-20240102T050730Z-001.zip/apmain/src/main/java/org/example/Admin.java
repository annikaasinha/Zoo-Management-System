package org.example;

public interface Admin extends Feedbackable{
    public void manageAttractions();
    //i'll make an interface for manage attractions
    //then a class of attractions that implements that
    public void manageAnimals();
    //i'll make an interface for manage animals
    //then a class of animals that implements that
    public void scheduleEvents();
    public void setDiscounts();
    public void setSpecialDeals();
    public void viewVisitorStats(VisitorManager visitorManager);
    public void viewFeedback();
}
