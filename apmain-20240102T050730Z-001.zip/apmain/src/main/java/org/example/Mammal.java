package org.example;

public class Mammal extends Animal {
    //when i add animals in the main class initially there needs to be at least 2 animals
    public Mammal(String animalName, String description, String feedNoise) {
        super(animalName, description, feedNoise);
    }
}
