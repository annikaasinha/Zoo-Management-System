package org.example;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
        //initialize all the arraylists with some values within
        String username = "admin";
        String password = "admin123";
        Scanner sc = new Scanner(System.in);
        //using polymorphism here
        Animal mammal1 = new Mammal("Lion", "The lion is a large cat of the genus Panthera native to Africa and India. It has a muscular, broad-chested body; short, rounded head; round ears; and a hairy tuft at the end of its tail.", "Roar");
        Animal mammal2 = new Mammal("Elephant", "Elephantidae is a family of large, herbivorous proboscidean mammals collectively called elephants and mammoths. These are large terrestrial mammals with a snout modified into a trunk and teeth modified into tusks.", "Elephants trumpet");
        Animal amphibian1 = new Amphibian("Axolotl", "The axolotl is a paedomorphic salamander closely related to the tiger salamander. It is unusual among amphibians in that it reaches adulthood without undergoing metamorphosis. ", "hiccuping, and squeaking");
        Animal amphibian2 = new Amphibian("Salamander", "Salamanders are a group of amphibians typically characterized by their lizard-like appearance, with slender bodies, blunt snouts, short limbs projecting at right angles to the body, and the presence of a tail in both larvae and adults", "quiet ticking or popping noises");
        Animal reptile1 = new Reptile("Iguana", "Iguana is a genus of herbivorous lizards that are native to tropical areas of Mexico, Central America, South America, and the Caribbean.", "cough or sneeze");
        Animal reptile2 = new Reptile("Alligator", "An alligator, or colloquially gator, is a large reptile in the Crocodilia order in the genus Alligator of the family Alligatoridae. The two extant species are the American alligator and the Chinese alligator. ", " rumbling noise ");
        ZooManager zoo = new ZooManager();
        VisitorStats visitorStats = new VisitorStats(0, 0);
        zoo.getAnimalArrayList().add(mammal1);
        zoo.getAnimalArrayList().add(mammal2);
        zoo.getAnimalArrayList().add(amphibian1);
        zoo.getAnimalArrayList().add(amphibian2);
        zoo.getAnimalArrayList().add(reptile1);
        zoo.getAnimalArrayList().add(reptile2);
        VisitorManager visitorManager = new VisitorManager();
        while (true) {
            System.out.println("Welcome to ZOOtopia!\n" +
                    "\n" +
                    "1. Enter as Admin\n" +
                    "2. Enter as a Visitor\n" +
                    "3. View Special Deals\n" +
                    "4. Exit");
            int firstOption = sc.nextInt();


            if (firstOption == 1) {

                System.out.println("Enter your username:");
                String username1 = sc.next();
                System.out.println("Enter your password:");
                String password1 = sc.next();

                if ((username1.equals(username)) && (password1.equals(password))) {
                    System.out.println("Logged in as admin.");
                    while (true) {
                        System.out.println("Admin Menu:\n" +
                                "1. Manage Attractions\n" +
                                "2. Manage Animals\n" +
                                "3. Schedule Events\n" +
                                "4. Set Discounts\n" +
                                "5. Set Special Deal\n" +
                                "6. View Visitor Stats\n" +
                                "7. View Feedback\n" +
                                "8. Exit\n");

                        System.out.println("Enter your choice:");
                        int adminOption = sc.nextInt();
                        if (adminOption == 1) {
                            zoo.manageAttractions();
                        } else if (adminOption == 2) {
                            //i'll create my own description for the animals because its a parameter in the
                            //parent class
                            zoo.manageAnimals();

                        } else if (adminOption == 3) {
                            zoo.scheduleEvents();

                        } else if (adminOption == 4) {
                            zoo.setDiscounts();

                        } else if (adminOption == 5) {
                            zoo.setSpecialDeals();

                        } else if (adminOption == 6) {
                            zoo.viewVisitorStats(visitorManager);

                        } else if (adminOption == 7) {
                            zoo.viewFeedback();

                        } else if (adminOption == 8) {
                            break;

                        }
                    }

                } else {
                    System.out.println("Incorrect credentials");
                }

            } else if (firstOption == 2) {
                visitorStats.setNoOfVisitors(visitorStats.getNoOfVisitors() + 1);
                boolean canRegister=false;
                System.out.println("1. Register\n" +
                        "2. Login\n");
                int visitorOption = sc.nextInt();
                if (visitorOption == 1) {
                    visitorManager.register(zoo);
                    canRegister=true;
                } else if (visitorOption == 2) {
                    canRegister=visitorManager.login(zoo);
                }
                while (canRegister) {
                    System.out.println("Visitor Menu:\n" +
                            "1. Explore the Zoo\n" +
                            "2. Buy Membership\n" +
                            "3. Buy Tickets\n" +
                            "4. View Discounts\n" +
                            "5. View Special Deals\n" +
                            "6. Visit Animals\n" +
                            "7. Visit Attractions\n" +
                            "8. Leave Feedback\n" +
                            "9. Log Out\n");
                    int visitorMenuOption = sc.nextInt();
                    if (visitorMenuOption == 1) {
                        visitorManager.exploreZoo(zoo);
                    }
                    if (visitorMenuOption == 2) {
                        visitorManager.buyMembership(zoo);
                    } else if (visitorMenuOption == 3) {
                        visitorManager.buyTickets(zoo);

                    } else if (visitorMenuOption == 4) {
                        visitorManager.viewDiscounts(zoo);
                    } else if (visitorMenuOption == 5) {
                        visitorManager.viewSpecialDeals(zoo);

                    } else if (visitorMenuOption == 6) {
                        visitorManager.visitAnimals(zoo);

                    } else if (visitorMenuOption == 7) {
                        visitorManager.visitAttraction(zoo);
                    } else if (visitorMenuOption == 8) {
                        visitorManager.provideFeedback(zoo);
                    }
                    else if(visitorMenuOption==9){
                        break;
                    }
                }
            } else if (firstOption==3) {
                for (SpecialDeals specialDeals : zoo.getSpecialDealsArrayList()) {
                    System.out.println(specialDeals);
                }
            }
            else if(firstOption==4){
                break;
            }
        }
    }
}
