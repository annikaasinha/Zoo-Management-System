package org.example;

public class SpecialDeals {
    private int noOfAttractionsBought;
    private double correspondingDeals;
    //corresponding deal is not the percentage but the percentage divided by 100
    public SpecialDeals(int noOfAttractionsBought, double correspondingDeals){
        this.noOfAttractionsBought=noOfAttractionsBought;
        this.correspondingDeals=correspondingDeals;
    }

    public double getCorrespondingDeals() {
        return correspondingDeals;
    }

    public void setNoOfAttractionsBought(int noOfAttractionsBought) {
        this.noOfAttractionsBought = noOfAttractionsBought;
    }

    public int getNoOfAttractionsBought() {
        return noOfAttractionsBought;
    }

    public void setCorrespondingDeals(double correspondingDeals) {
        this.correspondingDeals = correspondingDeals;
    }

    @Override
    public String toString() {
        return "After buying "+this.getNoOfAttractionsBought()+" You get"+(this.correspondingDeals*100)+"%off";
    }
}
