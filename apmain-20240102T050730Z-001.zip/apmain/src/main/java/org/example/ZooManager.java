package org.example;

import org.w3c.dom.Attr;

import java.util.ArrayList;
import java.util.Scanner;

public class ZooManager implements Admin{
    private ArrayList<Animal> animalArrayList;
    private ArrayList<Attraction> attractionArrayList;
    private int idGenerator=0;
    private ArrayList<SpecialDeals> specialDealsArrayList=new ArrayList<>();
    private Mammal dummyMammal=new Mammal("Pig", "The pig, often called swine, hog, or domestic pig when distinguishing from other members of the genus Sus, is an omnivorous, domesticated, even-toed, hoofed mammal. It is variously considered a subspecies of Sus scrofa or a distinct species.", "Huff");
    private Attraction dummyAttraction=new Attraction("Garden", "Pretty Garden", 111111, 10);
    private MinorDiscount minorDiscount=new MinorDiscount(0.1);
    private SeniorDiscount seniorDiscount=new SeniorDiscount(0.2);
    private VisitorStats visitorStats =new VisitorStats(0, 0);
    //should i make visitor stats an arraylist??
    private ArrayList<Feedback> feedbackArrayList= new ArrayList<Feedback>();
    private Feedback dummyFeedback=new Feedback("Amazing zoo!");
    private SpecialDeals specialDeals1=new SpecialDeals(2,0.15);
    private SpecialDeals specialDeals2=new SpecialDeals(3,0.3);
//im not providing getters and setters for the above 2 as they're not important they're just to ensure that these two lists are not null
public ZooManager(){
    animalArrayList=new ArrayList<>();
    attractionArrayList=new ArrayList<>() ;
    animalArrayList.add(this.dummyMammal);
    attractionArrayList.add(this.dummyAttraction);
    feedbackArrayList.add(dummyFeedback);
    specialDealsArrayList.add(specialDeals1);
    specialDealsArrayList.add(specialDeals2);

}
    public void setAnimalArrayList(ArrayList<Animal> animalArrayList) {
        this.animalArrayList = animalArrayList;
    }



    public MinorDiscount getMinorDiscount() {
        return minorDiscount;
    }

    public Attraction getDummyAttraction() {
        return dummyAttraction;
    }

    public Mammal getDummyMammal() {
        return dummyMammal;
    }

    public SeniorDiscount getSeniorDiscount() {
        return seniorDiscount;
    }

    public Feedback getDummyFeedback() {
        return dummyFeedback;
    }

    public VisitorStats getVisitorStats() {
        return visitorStats;
    }

    public void setDummyAttraction(Attraction dummyAttraction) {
        this.dummyAttraction = dummyAttraction;
    }

    public void setDummyMammal(Mammal dummyMammal) {
        this.dummyMammal = dummyMammal;
    }

    public void setDummyFeedback(Feedback dummyFeedback) {
        this.dummyFeedback = dummyFeedback;
    }

    public void setFeedbackArrayList(ArrayList<Feedback> feedbackArrayList) {
        this.feedbackArrayList = feedbackArrayList;
    }

    public void setMinorDiscount(MinorDiscount minorDiscount) {
        this.minorDiscount = minorDiscount;
    }

    public void setSpecialDealsArrayList(ArrayList<SpecialDeals> specialDealsArrayList) {
        this.specialDealsArrayList = specialDealsArrayList;
    }

    public void setSeniorDiscount(SeniorDiscount seniorDiscount) {
        this.seniorDiscount = seniorDiscount;
    }

    public void setVisitorStats(VisitorStats visitorStats) {
        this.visitorStats = visitorStats;
    }


    public int getIdGenerator() {
        return idGenerator;
    }

    public void setIdGenerator(int idGenerator) {
        this.idGenerator = idGenerator;
    }

    public ArrayList<Animal> getAnimalArrayList() {
        return animalArrayList;
    }

    public ArrayList<Attraction> getAttractionArrayList() {
        return attractionArrayList;
    }

    public void setAttractionArrayList(ArrayList<Attraction> attractionArrayList) {
        this.attractionArrayList = attractionArrayList;
    }

    @Override
    public void manageAttractions() {
        while (true) {
//i'm setting the price of all the attractions to be 10 initially
            Scanner sc = new Scanner(System.in);
            System.out.println("Manage Attractions:\n" +
                    "1. Add Attraction\n" +
                    "2. View Attractions\n" +
                    "3. Modify Attraction\n" +
                    "4. Remove Attraction\n" +
                    "5. Exit\n");
            System.out.println("Enter your choice:");
            int attractionOption = sc.nextInt();
            if (attractionOption == 1) {
                System.out.println("Enter Attraction Name:");
                sc.nextLine();
                String attractionName = sc.nextLine();
                System.out.println("Enter Attraction Description: ");
                String attractionDescription = sc.nextLine();
                Attraction attraction=new Attraction(attractionName, attractionDescription, idGenerator, 10);
                this.getAttractionArrayList().add(attraction);
                this.setIdGenerator(idGenerator+1);
                System.out.println("Attraction added successfully!");
            } else if (attractionOption == 2) {
                for (Attraction attraction: this.getAttractionArrayList()){
                    //this is printing my dummy attraction as well
                    System.out.println(attraction);
                }

            } else if (attractionOption == 4) {
                System.out.println("Enter the attraction id of the attraction you want to remove");
                int attractionId=sc.nextInt();
                for(Attraction attraction: this.getAttractionArrayList()){
                    if(attraction.getAttractionID()==attractionId) {
                        this.getAttractionArrayList().remove(attraction);
                        System.out.println("Attraction removed successfully!");
                    }
                }
            } else if (attractionOption == 3) {
                System.out.println("Enter the attraction id of the attraction you want to modify");
                int attractionId=sc.nextInt();
                System.out.println("Would you like to\n1.Modify the name \n2.Modify the description\n3. Add an animal\n4.Set the price of an attraction");
                int attractionModificationOption=sc.nextInt();
                if(attractionModificationOption==1){
                    System.out.println("Enter the modified name: ");
                    sc.nextLine();
                    String newName=sc.nextLine();
                    for(Attraction attraction: this.getAttractionArrayList()){
                        if(attraction.getAttractionID()==attractionId) {
                            attraction.setName(newName);
                            System.out.println("Name modified successfully");
                        }
                    }
                }
                else if(attractionModificationOption==2){
                    System.out.println("Enter the modified description");
                    sc.nextLine();
                    String newDescription=sc.nextLine();
                    for (Attraction attraction: this.getAttractionArrayList()){
                        if(attraction.getAttractionID()==attractionId) {
                            attraction.setDescription(newDescription);
                            System.out.println("Description modified successfully");
                        }
                    }
                } else if (attractionModificationOption==3) {
                    System.out.println("Enter the type of the animal you want to add\n1.Mammal\n2.Amphibian\n3.Reptile");
                    int animalType=sc.nextInt();

                    if(animalType==1){
                        System.out.println("Enter the animal Name");
                        sc.nextLine();
                        String animalName=sc.nextLine();
                        System.out.println("Enter the animal description");
                        String animalDescription=sc.nextLine();
                        System.out.println("Enter the noise that the animal makes on feeding");
                        String feedNoise=sc.nextLine();
                        Mammal newAnimal=new Mammal(animalName, animalDescription,feedNoise);
                        for(Attraction attraction: this.getAttractionArrayList()) {
                            if(attraction.getAttractionID()==attractionId) {
                                attraction.getAnimalArrayList().add(newAnimal);
                                System.out.println("Animal added to attraction successfully!");
                            }
                        }
                    }
                    else if(animalType==2){
                        System.out.println("Enter the animal Name");
                        String animalName=sc.nextLine();
                        String animalDescription="This is an amphibian";
                        System.out.println("Enter the noise that the animal makes on feeding");
                        String feedNoise=sc.nextLine();
                        Amphibian newAnimal=new Amphibian(animalName, animalDescription, feedNoise);
                        for(Attraction attraction: this.getAttractionArrayList()) {
                            if(attraction.getAttractionID()==attractionId) {
                                attraction.getAnimalArrayList().add(newAnimal);
                                System.out.println("Animal added to attraction successfully!");
                            }
                        }
                    } else if (animalType==3) {
                        System.out.println("Enter the animal Name");
                        sc.nextLine();
                        String animalName=sc.nextLine();
                        System.out.println("Enter the animal description");
                        String animalDescription=sc.nextLine();
                        System.out.println("Enter the noise that this animal makes on feeding");
                        String feedNoise=sc.nextLine();
                        Amphibian newAnimal=new Amphibian(animalName, animalDescription, feedNoise);
                        for(Attraction attraction: this.getAttractionArrayList()) {
                            if(attraction.getAttractionID()==attractionId) {
                                attraction.getAnimalArrayList().add(newAnimal);
                                System.out.println("Animal added to attraction successfully!");
                            }
                        }
                    }
                } else if (attractionModificationOption==4) {
                    System.out.println("Enter the price that you'd like to set the attraction price to: ");
                    double newPrice=sc.nextDouble();
                    for(Attraction attraction: this.getAttractionArrayList()) {
                        if(attraction.getAttractionID()==attractionId) {
                            attraction.setAttractionPrice(newPrice);
                        }
                    }


                }
            } else if (attractionOption == 5) {
                break;
            }
        }
    }

    @Override
    public void manageAnimals() {
    Scanner sc=new Scanner(System.in);
    while(true){
        System.out.println("\n" +
                "Manage Animals:\n" +
                "1. Add Animal\n" +
                "2. Update Animal Details\n" +
                "3. Remove Animal\n" +
                "4. Exit\n" +
                "\n");
        int animalOption=sc.nextInt();
        if(animalOption==1){
            System.out.println("Enter the type of the animal you'd like to add\n1.Mammal\n2.Amphibian\n3.Reptile");
            int animalType=sc.nextInt();
            System.out.println("Enter the name of the animal");
            sc.nextLine();
            String animalName=sc.nextLine();
            if(animalType==1){
                System.out.println("Enter the animal description");
                String animalDescription=sc.nextLine();
                System.out.println("Enter the noise the animal makes on feeding");
                String feedNoise=sc.nextLine();
                Mammal animal=new Mammal(animalName, "This is a mammal", feedNoise);
                this.getAnimalArrayList().add(animal);
                System.out.println("Animal added successfully");
            } else if (animalType==2) {
                System.out.println("Enter the animal description");
                String animalDescription=sc.nextLine();
                System.out.println("Enter the noise the animal makes on feeding");
                String feedNoise=sc.nextLine();
                Amphibian animal=new Amphibian(animalName, animalDescription, feedNoise);
                this.getAnimalArrayList().add(animal);
                System.out.println("Animal added successfully");

            } else if (animalType==3) {
                System.out.println("Enter the animal description");
                String animalDescription=sc.nextLine();
                System.out.println("Enter the noise the animal makes on feeding");
                String feedNoise=sc.nextLine();
                Reptile animal=new Reptile(animalName, animalDescription, feedNoise);
                this.getAnimalArrayList().add(animal);
                System.out.println("Animal added successfully");
            }
        } else if (animalOption==2) {
            //here i'm assuming that the animal you want to update is input in the exact same way as it was when it was added
            System.out.println("Enter the name of the animal whose details you'd like to edit");
            sc.nextLine();
            String animalName=sc.nextLine();
            for (Animal a:this.getAnimalArrayList()){
                if(a.getName().equals(animalName)){
                    System.out.println("Would you like to edit the\n1.Name\n2.Description");
                    int animalEditOption=sc.nextInt();
                    if(animalEditOption==1){
                        System.out.println("What would you like to set the name to?");
                        sc.nextLine();
                        String newAnimalName=sc.nextLine();
                        a.setName(newAnimalName);
                        System.out.println("Animal name edited successfully!");
                    } else if (animalEditOption==2) {
                        System.out.println("What would you like to set the description to");
                        sc.nextLine();
                        String animalDescription=sc.nextLine();
                        a.setDescription(animalDescription);
                        System.out.println("Animal description edited successfully");
                    }

                }
            }

        } else if (animalOption==3) {
            System.out.println("Enter the name of the animal you'd like to remove");
            sc.nextLine();
            String animalName=sc.nextLine();

            System.out.println("Enter its type \n1.Mammal\n2.Amphibian\n3.Reptile");
           int animalType=sc.nextInt();
           if(animalType==1) {
               Animal animalToRemove = new Mammal("dummy", "dummy", "dummy");


               for (Animal a : this.getAnimalArrayList()) {
                   if (a.getName().equals(animalName)) {
                       animalToRemove=a;
                   }
               }
               try {
                   this.getAnimalArrayList().remove(animalToRemove);
                   System.out.println("Animal removed successfully!");
               }
               catch(Exception e){
                   System.out.println("Invalid animal credentials");
           } }else if (animalType==2) {
               Animal animalToRemove = new Amphibian("dummy", "dummy", "dummy");


               for (Animal a : this.getAnimalArrayList()) {
                   if (a.getName().equals(animalName)) {
                       animalToRemove=a;
                   }
               }
               try {
                   this.getAnimalArrayList().remove(animalToRemove);
                   System.out.println("Animal removed successfully!");
               }
               catch(Exception e){
                   System.out.println("Invalid animal credentials");

           }

           }else if(animalType==3){
               Animal animalToRemove = new Reptile("dummy", "dummy", "dummy");


               for (Animal a : this.getAnimalArrayList()) {
                   if (a.getName().equals(animalName)) {
                       animalToRemove=a;
                   }
               }
               try {
                   this.getAnimalArrayList().remove(animalToRemove);
                   System.out.println("Animal removed successfully!");
               }
               catch(Exception e){
                   System.out.println("Invalid animal credentials");

               }

           }

        } else if (animalOption==4) {
            break;
        }

        }

    }

    @Override
    public void scheduleEvents() {
    Scanner sc=new Scanner(System.in);
        System.out.println("Enter the attraction id of the attraction which you'd like to open or close or set the price of");
        int attractionId=sc.nextInt();
        for(Attraction o: this.getAttractionArrayList()){
            if (o.getAttractionID()==attractionId){
                System.out.println("Would you like to\n1.Open\n2.Close\n3.Set the price");
                int scheduleEventsOption=sc.nextInt();
                if(scheduleEventsOption==1){
                    o.setOpen(true);
                    System.out.println("Attraction opened successfully");
                } else if (scheduleEventsOption==2) {
                    o.setOpen(false);
                    System.out.println("Attraction closed successfully");
                }
                else if(scheduleEventsOption==3){
                    System.out.println("What would you like to set the price to?");
                    double newPrice=sc.nextDouble();
                    o.setAttractionPrice(newPrice);
                    System.out.println("Price set successfully");
                }

            }
        }


    }

    @Override
    public void setDiscounts() {
    //discount is in percentage
    Scanner sc=new Scanner(System.in);
        System.out.println("would you like to set the discount for\n1.Minors\n2.Seniors?");
        int discountOption=sc.nextInt();
        if(discountOption==1){
            System.out.println("What would you like to set the discount value to?(please enter the percentage divided by 100)");
            double discountSetValue=sc.nextDouble();
            minorDiscount.setDiscount(discountSetValue);
            System.out.println("Discount value changed successfully!");
        }
        else if(discountOption==2){
            System.out.println("What would you like to set the discount value to?(please enter the percentage divided by 100)");
            double discountSetValue=sc.nextDouble();
            seniorDiscount.setDiscount(discountSetValue);
            //System.out.println(seniorDiscount.viewDiscount()); testing statement
            System.out.println("Discount value changed successfully!");
        }



    }

    @Override
    public void setSpecialDeals() {
    Scanner sc=new Scanner(System.in);
        System.out.println("Would you like to\n1.Add a special deal\n2.Remove a special deal");
        int addRemove=sc.nextInt();
        if (addRemove==1) {
            System.out.println("What would you like to set the lower limit of the attractions bought for the corresponding deal?");
            int lowerLimit = sc.nextInt();
            System.out.println("What discount percentage would you like to set these to?");
            double discountPercentage = sc.nextDouble();
            specialDealsArrayList.add(new SpecialDeals(lowerLimit, discountPercentage));
            System.out.println("Special deal successfully set!");
        } else if (addRemove==2) {
            System.out.println("What is the lower limit of the attractions bought for the special deal you wish to remove?");
            int lowerLimit=sc.nextInt();
            SpecialDeals toRemove=new SpecialDeals(0,0);
            //dummy special deal
            for(SpecialDeals s: specialDealsArrayList){
                if(lowerLimit==s.getNoOfAttractionsBought()){
                    toRemove=s;
                }
            }
            specialDealsArrayList.remove(toRemove);
            System.out.println("Deal Removed successfully");

        }

    }

    @Override
    public void viewVisitorStats(VisitorManager visitorManager) {
        System.out.println(visitorStats);
        int max=0;
        Attraction bufferAttraction=new Attraction("dummy", "dummy", 1, 10);
        for(Attraction attraction:this.getAttractionArrayList()){
            if(attraction.getNumberOfTicketedVisitors()>max){
                max= attraction.getNumberOfTicketedVisitors();
                bufferAttraction=attraction;
            }
        }
        System.out.println("Most popular attraction:"+bufferAttraction.getName());

    }

    public ArrayList<SpecialDeals> getSpecialDealsArrayList() {
        return specialDealsArrayList;
    }

    public ArrayList<Feedback> getFeedbackArrayList() {
        return feedbackArrayList;
    }

    @Override
    public void addFeedback(String feedback){
        System.out.println("wrong interface is being used");
    }


    @Override
    public void viewFeedback() {
        for(Feedback feedback1: this.getFeedbackArrayList())
        {
            System.out.println(feedback1.getFeedback());
        }



    }










}
