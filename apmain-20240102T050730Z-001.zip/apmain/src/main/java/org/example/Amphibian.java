package org.example;

public class Amphibian extends Animal{

    public Amphibian(String animalName, String description, String feedNoise) {
        super(animalName, description, feedNoise);
    }



}
