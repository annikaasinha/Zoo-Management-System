package org.example;

import java.util.ArrayList;
import java.util.Objects;

public class BasicMembership {
//im implementing the object class methods here
private ArrayList<Attraction> ticketsBought=new ArrayList<>();
private int noOfTicketsBought=0;

    public ArrayList<Attraction> getTicketsBought() {
        return ticketsBought;
    }

    public void setTicketsBought(ArrayList<Attraction> ticketsBought) {
        this.ticketsBought = ticketsBought;
    }

    public int getNoOfTicketsBought() {
        return noOfTicketsBought;
    }

    public void setNoOfTicketsBought(int noOfTicketsBought) {
        this.noOfTicketsBought = noOfTicketsBought;
    }
}
