package org.example;

public interface Discountable {
    public double viewDiscount();
    public void setDiscount (double Discount);
}
