package org.example;

public interface Visitor {
public void register(ZooManager zoo);
public boolean login(ZooManager zoo);
public void exploreZoo(ZooManager zoo);
public void buyMembership(ZooManager zoo);
public void buyTickets(ZooManager zoo);
public void viewDiscounts(ZooManager zoo);
public void applyDiscounts();
public void visitAttraction(ZooManager zoo);
public void provideFeedback(ZooManager zoo);
public void viewSpecialDeals(ZooManager zoo);
public void visitAnimals(ZooManager zoo);
}
