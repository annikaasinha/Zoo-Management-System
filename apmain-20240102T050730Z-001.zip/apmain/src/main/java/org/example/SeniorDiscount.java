package org.example;

public class SeniorDiscount implements Discountable {
    //this is not the discount percentage but the actual discount
    private double discount;
    public SeniorDiscount(double discountPercentage){
        this.discount=discountPercentage;
    }

    @Override
    public String toString() {
        return " "+this.viewDiscount();
    }

    @Override
    public double viewDiscount() {
        return this.discount;
    }

    @Override
    public void setDiscount(double Discount) {
        this.discount=Discount;

    }

}
